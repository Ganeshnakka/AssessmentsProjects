package com.devskiller.tasks.blog.model.dto;

public record NewCommentDto(String author, String content) {
}
